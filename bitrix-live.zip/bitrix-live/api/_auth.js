import crypto from "crypto";

// Пароли нигде не хранятся в открытом виде — только bcrypt-хеши.
// Поменять пароль: сгенерируйте новый хеш (см. README, раздел «Как поменять пароль»)
// и замените соответствующую строку ниже.
export const ACCOUNTS = [
  { login: "head", passwordHash: "$2b$10$pCFbLT6RMtbVd5NTIBbKRuzo3nRzGlA22cLNIW0MBXQQ2TfdqxKom", name: "Главный менеджер", role: "head", bitrixId: null },
  { login: "boboev", passwordHash: "$2b$10$rDfJEduzHSpeY2EIU93AHOpwruMmt/a14T/C/LG5rp0WoKjPhRvVK", name: "Zuljalol Boboev", role: "manager", bitrixId: "12" },
  { login: "kalonov", passwordHash: "$2b$10$lRDn5LP77SC6t7foJ.8FbuN0piMclr.YlpqdldhhYOD0YvmEA7HOW", name: "Хурдак Калонов", role: "manager", bitrixId: "14" },
  { login: "khodiev", passwordHash: "$2b$10$4fdxG9ZPAM2G8kEkyu/CweGU/96X8.8foCpr5bu/J3.TZhWrMMgya", name: "Азиз Ходиев", role: "manager", bitrixId: "16" },
  { login: "khodieva", passwordHash: "$2b$10$lbsXrmAEGXqT.NJAkLJ2S.f3RodDoYM.N7ozVyAvcvJUhjS.8C0k.", name: "Азиза Ходиева", role: "manager", bitrixId: "18" },
];

// Секрет для подписи cookie. Лучше задать свой в переменной окружения
// SESSION_SECRET на Vercel — если её нет, используется запасной (это ок
// для теста, но для боевого использования задайте SESSION_SECRET).
const SECRET = process.env.SESSION_SECRET || "dev-fallback-secret-change-me";
const MAX_AGE = 60 * 60 * 24 * 7; // 7 дней

function b64url(buf) {
  return Buffer.from(buf).toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}
function fromB64url(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return Buffer.from(s, "base64").toString("utf8");
}
function sign(payloadObj) {
  const payload = b64url(JSON.stringify(payloadObj));
  const sig = b64url(crypto.createHmac("sha256", SECRET).update(payload).digest());
  return `${payload}.${sig}`;
}
function verify(token) {
  if (!token) return null;
  const parts = token.split(".");
  if (parts.length !== 2) return null;
  const [payload, sig] = parts;
  const expected = b64url(crypto.createHmac("sha256", SECRET).update(payload).digest());
  const a = Buffer.from(sig), b = Buffer.from(expected);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  let data;
  try { data = JSON.parse(fromB64url(payload)); } catch { return null; }
  if (!data.exp || data.exp < Date.now()) return null;
  return data;
}
function parseCookies(req) {
  const h = req.headers.cookie || "";
  const out = {};
  h.split(";").forEach((p) => {
    const i = p.indexOf("=");
    if (i === -1) return;
    out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim());
  });
  return out;
}
export function getSession(req) {
  const cookies = parseCookies(req);
  return verify(cookies.session);
}
export function setSessionCookie(res, data) {
  const token = sign({ ...data, exp: Date.now() + MAX_AGE * 1000 });
  res.setHeader("Set-Cookie", `session=${token}; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=${MAX_AGE}`);
}
export function clearSessionCookie(res) {
  res.setHeader("Set-Cookie", `session=; HttpOnly; Secure; SameSite=Lax; Path=/; Max-Age=0`);
}
