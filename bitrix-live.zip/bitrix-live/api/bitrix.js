import { getSession } from "./_auth.js";

// Серверная функция-прокси. Выполняется на сервере Vercel, а не в браузере,
// поэтому ссылка вебхука (BITRIX_WEBHOOK) никогда не попадает в код страницы.
//
// Доступ проверяется здесь же: без действительной сессии (cookie) запрос
// отклоняется. Для роли "manager" фильтр по ответственному подставляется
// принудительно — клиент не может его обойти, даже отправив свой filter.
const ALLOWED = new Set([
  "crm.deal.list",
  "crm.deal.get",
  "user.get",
  "tasks.task.list",
  "tasks.task.get",
  "crm.activity.list",
  "crm.activity.get",
  "disk.attachedObject.get",
  "disk.file.get",
  "disk.storage.getlist",
  "disk.storage.getchildren",
]);

async function call(base, method, params) {
  const target = `${base.replace(/\/$/, "")}/${method}.json?${params.toString()}`;
  const r = await fetch(target);
  return r.json();
}

export default async function handler(req, res) {
  const session = getSession(req);
  if (!session) {
    res.status(401).json({ error: "auth_required" });
    return;
  }

  const base = process.env.BITRIX_WEBHOOK;
  if (!base) {
    res.status(500).json({ error: "BITRIX_WEBHOOK не задан в переменных окружения Vercel" });
    return;
  }

  const url = new URL(req.url, "http://localhost");
  const method = url.searchParams.get("method");
  if (!method || !ALLOWED.has(method)) {
    res.status(400).json({ error: "Метод не разрешён: " + method });
    return;
  }
  url.searchParams.delete("method");
  const isManager = session.role === "manager";
  const myId = session.bitrixId;

  // --- Разграничение по ролям ---
  if (isManager && method === "crm.deal.list") {
    // Какой бы фильтр ни прислала страница — подставляем свой, игнорируя чужой.
    for (const k of [...url.searchParams.keys()]) {
      if (k.toLowerCase().includes("assigned_by_id")) url.searchParams.delete(k);
    }
    url.searchParams.set("filter[ASSIGNED_BY_ID]", myId);
  }

  if (isManager && method === "tasks.task.list") {
    for (const k of [...url.searchParams.keys()]) {
      if (k.toLowerCase().includes("responsible_id")) url.searchParams.delete(k);
    }
    url.searchParams.set("filter[RESPONSIBLE_ID]", myId);
  }

  if (isManager && method === "tasks.task.get") {
    const data = await call(base, method, url.searchParams);
    const t = data && data.result && data.result.task;
    if (t && String(t.responsibleId) !== String(myId)) {
      res.status(403).json({ error: "forbidden" });
      return;
    }
    res.status(200).json(data);
    return;
  }

  if (isManager && (method === "crm.activity.list" || method === "disk.storage.getlist")) {
    // Эти методы принимают ID сделки напрямую — проверяем, что сделка
    // действительно принадлежит этому менеджеру, прежде чем выполнять запрос.
    const ownerId = url.searchParams.get("filter[OWNER_ID]") || url.searchParams.get("filter[ENTITY_ID]");
    if (ownerId) {
      const check = await call(base, "crm.deal.get", new URLSearchParams({ id: ownerId }));
      const deal = check && check.result;
      if (!deal || String(deal.ASSIGNED_BY_ID) !== String(myId)) {
        res.status(403).json({ error: "forbidden" });
        return;
      }
    }
  }

  try {
    const data = await call(base, method, url.searchParams);
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: String(err) });
  }
}
