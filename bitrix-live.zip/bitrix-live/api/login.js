import bcrypt from "bcryptjs";
import { ACCOUNTS, setSessionCookie } from "./_auth.js";

function readBody(req) {
  return new Promise((resolve) => {
    let data = "";
    req.on("data", (c) => (data += c));
    req.on("end", () => {
      try { resolve(JSON.parse(data || "{}")); } catch { resolve({}); }
    });
  });
}

export default async function handler(req, res) {
  if (req.method !== "POST") { res.status(405).json({ error: "method not allowed" }); return; }
  const { login, password } = await readBody(req);
  const acc = ACCOUNTS.find((a) => a.login === login);
  if (!acc || !password || !bcrypt.compareSync(password, acc.passwordHash)) {
    res.status(401).json({ error: "Неверный логин или пароль" });
    return;
  }
  setSessionCookie(res, { login: acc.login, role: acc.role, bitrixId: acc.bitrixId, name: acc.name });
  res.status(200).json({ ok: true, name: acc.name, role: acc.role });
}
