import { getSession } from "./_auth.js";

export default function handler(req, res) {
  const s = getSession(req);
  if (!s) { res.status(401).json({ error: "not_authenticated" }); return; }
  res.status(200).json({ login: s.login, role: s.role, bitrixId: s.bitrixId, name: s.name });
}
